#!/system/bin/sh

MODDIR=${0%/*}
sh "$MODDIR/wps_hsl_english.sh" >/dev/null 2>&1 &
