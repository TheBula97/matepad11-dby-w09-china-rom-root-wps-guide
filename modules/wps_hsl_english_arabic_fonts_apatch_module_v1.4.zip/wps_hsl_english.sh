#!/system/bin/sh

LOG=/data/local/tmp/hsl_wps_english.log
CFG_ROOT=/data/isula/var/lib/isulad/engines/lcr
EN="LANGUAGE=en_US.UTF-8"
ZH="LANGUAGE=zh_CN"
MUI=/data/isula/root-fs/opt/kingsoft/wps-office/office6/mui
ROOTFS=/data/isula/root-fs
FONT_DIR=$ROOTFS/usr/share/fonts/custom_arabic
POLICY=$MODDIR/hsl_font_policy.rules

log_msg() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >> "$LOG"
}

apply_policy() {
  [ -f "$POLICY" ] || return 1
  magiskpolicy --live --apply "$POLICY" >/dev/null 2>&1 && return 0
  return 1
}

patch_configs() {
  [ -d "$CFG_ROOT" ] || return 1

  find "$CFG_ROOT" -type f \( -name config -o -name config.json -o -name config.v2.json \) 2>/dev/null |
  while read -r cfg; do
    if grep -q "$ZH" "$cfg" 2>/dev/null; then
      sed -i "s/$ZH/$EN/g" "$cfg" && log_msg "patched $cfg"
    fi
  done
}

process_has_zh_language() {
  for pid in $(pidof HSLGd weston weston-keyboard weston-rdprail-shell wpsoffice wpscloudsvr 2>/dev/null); do
    if tr '\0' '\n' < "/proc/$pid/environ" 2>/dev/null | grep -q "^$ZH$"; then
      return 0
    fi
  done
  return 1
}

restart_hsl_session_if_needed() {
  if process_has_zh_language; then
    log_msg "old zh_CN HSL session detected; restarting HSL session"
    am force-stop com.huawei.hsl >/dev/null 2>&1
    for name in wpsoffice wpscloudsvr weston-rdprail-shell weston-keyboard weston HSLGd; do
      for pid in $(pidof "$name" 2>/dev/null); do
        kill -9 "$pid" >/dev/null 2>&1
      done
    done
  fi
}

force_mui_english() {
  [ -d "$MUI/en_US" ] || return 1

  if [ -d "$MUI/zh_CN" ] && [ ! -L "$MUI/zh_CN" ]; then
    TS=$(date +%Y%m%d_%H%M%S)
    mv "$MUI/zh_CN" "$MUI/zh_CN.backup_codex_$TS" && ln -s en_US "$MUI/zh_CN"
    log_msg "replaced zh_CN MUI with symlink to en_US"
    return 0
  fi

  if [ -L "$MUI/zh_CN" ]; then
    target=$(readlink "$MUI/zh_CN")
    if [ "$target" != "en_US" ]; then
      rm "$MUI/zh_CN" && ln -s en_US "$MUI/zh_CN"
      log_msg "refreshed zh_CN MUI symlink to en_US"
    fi
    return 0
  fi

  if [ ! -e "$MUI/zh_CN" ]; then
    ln -s en_US "$MUI/zh_CN"
    log_msg "created zh_CN MUI symlink to en_US"
  fi
}

install_arabic_fonts() {
  [ -d "$ROOTFS/usr/share/fonts" ] || return 1
  [ -d "$MODDIR/fonts" ] || return 1

  mkdir -p "$FONT_DIR" 2>/dev/null
  chmod 777 "$FONT_DIR" 2>/dev/null

  changed=0
  for font in trado.ttf tradbdo.ttf arabtype.ttf; do
    src="$MODDIR/fonts/$font"
    dst="$FONT_DIR/$font"
    [ -f "$src" ] || continue

    if [ ! -f "$dst" ] || [ "$(wc -c < "$src" 2>/dev/null)" != "$(wc -c < "$dst" 2>/dev/null)" ]; then
      cat "$src" > "$dst" 2>/dev/null && changed=1
    fi
    chmod 644 "$dst" 2>/dev/null
  done
  chmod 755 "$FONT_DIR" 2>/dev/null

  if [ "$changed" = "1" ]; then
    log_msg "installed Arabic fonts into $FONT_DIR"
  fi
}

log_msg "module watcher started"
apply_policy

while true; do
  apply_policy
  cfg_count=$(find "$CFG_ROOT" -type f \( -name config -o -name config.json -o -name config.v2.json \) 2>/dev/null | wc -l)
  patch_configs
  force_mui_english
  install_arabic_fonts
  restart_hsl_session_if_needed

  if [ "$cfg_count" -gt 0 ] && ! grep -q "$ZH" "$CFG_ROOT"/*/config "$CFG_ROOT"/*/config.json "$CFG_ROOT"/*/config.v2.json 2>/dev/null; then
    log_msg "English HSL environment is present"
  fi

  sleep 10
done
